# Đèn Deco — firmware 1.0.0

Đèn trang trí dùng ESP32-C3 SuperMini, 20 WS2812B và bốn TTP223. Điều khiển bằng cảm ứng hoặc web tiếng Việt ngay trên ESP; cập nhật firmware OTA qua web.

## Tải và nạp bằng Arduino IDE trên Windows

**[Tải gói Đèn Deco 1.0.0 (.zip)](https://github.com/NguyenPhat-NT/den_trang_tri/raw/refs/heads/main/downloads/DenDeco-1.0.0.zip)** · **[Tải hướng dẫn Word](https://github.com/NguyenPhat-NT/den_trang_tri/raw/refs/heads/main/HUONG_DAN.docx)**

1. Tải ZIP, giải nén cả gói.
2. Đọc `HUONG_DAN.docx` để xem bảng đấu nối và cài đặt IDE.
3. Mở `DenDeco/DenDeco.ino`, giữ các header trong cùng thư mục.
4. Cài **esp32 by Espressif Systems 2.0.17**, **Adafruit NeoPixel 1.12.5**, **ArduinoJson 7.4.2**.
5. Chọn **ESP32C3 Dev Module**, USB CDC On Boot **Enabled**, flash **4 MB** nếu đúng bo thực tế và Partition Scheme **Default 4MB with spiffs** có OTA. Nạp lần đầu qua USB.
6. Mở Serial Monitor 115200 baud để lấy mật khẩu AP riêng, nối AP `DenDeco-XXXXXX` và mở `http://192.168.4.1` để cấu hình WiFi nhà 2,4 GHz.

Toàn bộ web nằm trong firmware; không cần nạp filesystem hoặc cài ứng dụng điện thoại. Muốn lấy toàn repo, dùng **Code → Download ZIP** trên GitHub.

## Tính năng

- Bốn cảm ứng Nguồn / − / + / M, phân biệt chạm và giữ.
- Sáu chế độ ánh sáng, chuyển sáng mềm và thang cảm nhận gamma 2,2.
- Chế độ ngủ nhớ riêng mức sáng đã chỉnh, mặc định ban đầu 5%.
- Ba mục yêu thích; hẹn giờ 1–180 phút và giảm sáng trong năm phút cuối.
- Lưu trạng thái sau 10 giây không thay đổi, kiểm tra CRC và hai bản NVS.
- WiFi nhà + AP dự phòng; đồng bộ trạng thái các trình duyệt, không phát lại lệnh cũ khi kết nối lại.
- OTA bằng file ứng dụng ESP32-C3; giữ cấu hình NVS sau cập nhật.

## Các tệp trong dự án

| Đường dẫn | Nội dung |
| --- | --- |
| `DenDeco/` | Sketch chính và cấu hình tập trung |
| `LED_Check/LED_Check.ino` | Kiểm tra màu, LED 0/9/10/19, cặp cùng chiều cao và OUT cảm ứng ở mức thấp |
| `HUONG_DAN.docx` | Đấu nối, nạp lần đầu, web, WiFi, OTA và nghiệm thu |
| `docs/` | Hướng dẫn Markdown, cấu hình/kế hoạch, kiểm thử và thông tin build |
| `firmware/DenDeco-1.0.0-ota.bin` | File ứng dụng đã biên dịch cho OTA sau lần nạp USB đầu |
| `firmware/SHA256SUMS.txt` | SHA-256 của file ứng dụng |
| `tests/` | Kiểm tra logic, lưu trữ và web |
| `platformio.ini` | Cấu hình build đã kiểm chứng; không bắt buộc cho Arduino IDE |
| `downloads/DenDeco-1.0.0.zip` | Gói bàn giao đủ mã nguồn, hướng dẫn Word và file OTA |

## Cấu hình và kiểm chứng

Nguồn tham chiếu **5 V–2 A**; 20 LED chia hai đoạn 10. Nguồn/−/+/M dùng GPIO **0/1/3/4**, dữ liệu LED GPIO **5**. TTP223 cấp **3,3 V**, direct/momentary active high. Vỏ do người lắp tự thiết kế.

Đã biên dịch cho ESP32-C3 với các phiên bản core/thư viện ở trên. Đã kiểm tra logic, lưu trữ mô phỏng lỗi và giao diện trên Chromium với API mô phỏng. **Chưa nạp, đo nguồn/nhiệt hoặc thử OTA trên bo thật.** Trần đầu ra ban đầu 30% không xác nhận khả năng chịu dòng của đường USB-C → chân 5V trên SuperMini; làm các bước thử trong hướng dẫn trước khi dùng lâu dài.

OTA chỉ cập nhật ứng dụng; đổi bảng phân vùng hoặc phục hồi firmware lỗi cần USB. File OTA không phải bootloader hoặc file flash gộp. Không có SSID/mật khẩu WiFi nhà trong mã nguồn: cấu hình tại thiết bị.
